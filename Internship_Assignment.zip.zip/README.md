This is an internship assignment given by Celebrare Company

Libraries used:
1) Jquery.js
2) Google Fonts
3) Font Awesome icons
4) Swiper css and js CDN

=> Images are used from Asstes folder, provided by Celebrare Company
=> Golden flower png is downloaded from pngfree.com

